#!/usr/bin/env python3

# ===============================
# Modules
# ===============================
import argparse
import sys
import os
import subprocess
import json

# Auto install requests if missing
try:
    import requests
except ImportError:
    print("[*] Installing missing module: requests")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "requests"])
    import requests


# Auto ensure lolcat exists (optional)
def ensure_lolcat():
    if os.system("command -v lolcat > /dev/null 2>&1") != 0:
        print("[*] Installing lolcat...")
        os.system("pkg install -y ruby >/dev/null 2>&1")
        os.system("gem install lolcat >/dev/null 2>&1")


ensure_lolcat()


# ===============================
# Argument Parser
# ===============================
parser = argparse.ArgumentParser(description="IPDrone - IP Information Tool")
parser.add_argument(
    "-v",
    help="Target/Host IP address",
    type=str,
    dest="target",
    required=True,
)

args = parser.parse_args()
ip = args.target


# ===============================
# Colours
# ===============================
red = "\033[31m"
yellow = "\033[93m"
lgreen = "\033[92m"
clear = "\033[0m"
bold = "\033[1m"
cyan = "\033[96m"


# ===============================
# Banner
# ===============================
print(
    yellow
    + r"""
  ___ ___ _               _
 |_ _| _ \ |_ _ _ __ _ __| |__
  | ||  _/  _| '_/ _` / _| / /
 |___|_|  \__|_| \__,_\__|_\_\
                       v 1.0.0
"""
    + clear
)

print(lgreen + bold + " Source from: termux-app-store \n" + clear)


# ===============================
# API Request
# ===============================
api = "https://ipwho.is/"

try:
    response = requests.get(api + ip, timeout=10)
    data = response.json()

    # Debug raw response (optional)
    # print(json.dumps(data, indent=4))

    if not data.get("success", False):
        print(red + "[!] Invalid, Private, or Unreachable IP Address" + clear)
        sys.exit(1)

    a = lgreen + bold + "[>]" + clear
    b = lgreen + bold + "[>]" + clear

    print(a, "[Victim]:", data.get("ip", "N/A"))
    print(red + "<--------------->" + clear)

    print(b, "[ISP]:", data.get("connection", {}).get("isp", "N/A"))
    print(red + "<--------------->" + clear)

    print(a, "[Organisation]:", data.get("connection", {}).get("org", "N/A"))
    print(red + "<--------------->" + clear)

    print(b, "[City]:", data.get("city", "N/A"))
    print(red + "<--------------->" + clear)

    print(a, "[Region]:", data.get("region", "N/A"))
    print(red + "<--------------->" + clear)

    print(b, "[Longitude]:", data.get("longitude", "N/A"))
    print(red + "<--------------->" + clear)

    print(a, "[Latitude]:", data.get("latitude", "N/A"))
    print(red + "<--------------->" + clear)

    print(b, "[Time zone]:", data.get("timezone", {}).get("id", "N/A"))
    print(red + "<--------------->" + clear)

    print(a, "[Zip code]:", data.get("postal", "N/A"))
    print()

except KeyboardInterrupt:
    print("\nTerminating, Bye" + lgreen)
    sys.exit(0)

except requests.exceptions.ConnectionError:
    print(red + "[~] Check your internet connection!" + clear)
    sys.exit(1)

except requests.exceptions.Timeout:
    print(red + "[~] Request timed out!" + clear)
    sys.exit(1)

except Exception as e:
    print(red + f"[!] Unexpected error: {e}" + clear)
    sys.exit(1)
