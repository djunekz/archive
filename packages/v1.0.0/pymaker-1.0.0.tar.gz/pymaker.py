import os
import argparse
import logging
from datetime import datetime

def setup_logging(level=logging.INFO):
    """
    Mengatur konfigurasi logging dasar.
    """
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler()
        ]
    )
    return logging.getLogger(__name__)

logger = setup_logging()

def generate_python_script_content(script_name, description="Deskripsi singkat tentang fungsionalitas skrip ini.", author="Nama Anda"):
    """
    Menghasilkan string konten untuk skrip Python baru.
    """
    current_year = datetime.now().year
    content = f'''"""
{script_name.replace('.py', '').replace('_', ' ').title()}

{description}

Author: {author}
Date: {datetime.now().strftime('%Y-%m-%d')}
License: MIT (atau lisensi lain yang Anda pilih)
Copyright (c) {current_year} {author}
"""

import sys
import argparse
import logging

# Konfigurasi logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def example_function(input_data: str) -> str:
    """
    Contoh fungsi untuk mendemonstrasikan struktur.

    Args:
        input_data (str): Data masukan untuk fungsi ini.

    Returns:
        str: Hasil pemrosesan data.
    """
    logger.info(f"Mengeksekusi example_function dengan input: {{input_data}}")
    # Tulis logika fungsi Anda di sini
    processed_data = f"Data diproses: {{input_data.upper()}}"
    return processed_data

def main():
    """
    Fungsi utama dari skrip ini.
    Mengurai argumen baris perintah dan menjalankan logika utama.
    """
    parser = argparse.ArgumentParser(
        description="{description}",
        formatter_class=argparse.RawTextHelpFormatter
    )
    parser.add_argument(
        '-i', '--input',
        type=str,
        required=True,
        help='Contoh argumen masukan.'
    )
    parser.add_argument(
        '-v', '--verbose',
        action='store_true',
        help='Meningkatkan verbositas output logging.'
    )

    args = parser.parse_args()

    if args.verbose:
        logger.setLevel(logging.DEBUG)
        logger.debug("Mode verbose diaktifkan.")

    logger.info("Skrip dimulai.")

    try:
        result = example_function(args.input)
        logger.info(f"Hasil: {{result}}")
    except Exception as e:
        logger.error(f"Terjadi kesalahan: {{e}}")
        sys.exit(1)

    logger.info("Skrip selesai.")

if __name__ == "__main__":
    main()
'''
    return content

def create_python_script(file_path, description, author):
    """
    Membuat file skrip Python baru dengan konten yang dihasilkan.
    """
    try:
        # Pastikan direktori ada jika file_path menyertakan direktori
        os.makedirs(os.path.dirname(file_path) or '.', exist_ok=True)

        with open(file_path, 'w') as f:
            content = generate_python_script_content(os.path.basename(file_path), description, author)
            f.write(content)
        logger.info(f"Skrip Python '{file_path}' berhasil dibuat.")
    except IOError as e:
        logger.error(f"Gagal menulis file '{file_path}': {e}")
        raise
    except Exception as e:
        logger.error(f"Terjadi kesalahan tak terduga saat membuat skrip: {e}")
        raise

def main_creator():
    """
    Fungsi utama untuk menjalankan pembuat skrip.
    """
    parser = argparse.ArgumentParser(
        description="Alat untuk membuat skrip Python baru dengan struktur profesional.",
        formatter_class=argparse.RawTextHelpFormatter
    )
    parser.add_argument(
        '--name',
        type=str,
        required=False,
        help='Nama file skrip Python yang akan dibuat (contoh: my_script.py).'
    )
    parser.add_argument(
        '--description',
        type=str,
        default="Deskripsi singkat tentang fungsionalitas skrip ini.",
        help='Deskripsi untuk docstring skrip baru.'
    )
    parser.add_argument(
        '--author',
        type=str,
        default="djunekz",
        help='Nama penulis untuk docstring skrip baru.'
    )
    parser.add_argument(
        '-v', '--verbose',
        action='store_true',
        help='Meningkatkan verbositas output logging dari pembuat skrip.'
    )

    args = parser.parse_args()

    if args.verbose:
        logger.setLevel(logging.DEBUG)
        logger.debug("Mode verbose pembuat skrip diaktifkan.")

    script_name = args.name
    if not script_name:
        script_name = input("Masukkan nama file skrip Python yang ingin Anda buat (contoh: my_script.py): ")
        if not script_name.strip():
            logger.error("Nama skrip tidak boleh kosong. Membatalkan operasi.")
            return
    
    if not script_name.endswith('.py'):
        script_name += '.py'

    description = args.description
    author = args.author

    create_python_script(script_name, description, author)

if __name__ == "__main__":
    main_creator()
